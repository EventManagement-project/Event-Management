import React from 'react'
function Contacts(){
    return(
        <div>
            <div className="row  justify-content-center align-content-center banner">
                    <h3 className="font-weight-light font-italic">
                        Contacts us
                    </h3>
                    <h4 className="font-weight-light font-italic">
                        Gmail : test@gmail.com
                    </h4>
                    <h4 className="font-weight-light font-italic">
                        Phone no : 0000000000
                    </h4>
                    <h4 className="font-weight-light font-italic">
                        Office Address: Baner
                    </h4>
            </div>
        </div>
    )
}
export default Contacts;