import React, { Component } from 'react'

 class Navbar extends Component {
    render() {
        return (
            <nav className="navbar navbar-expand-sm navbar-light bg-dark fixed-top">
            <a href="#" className="navbar-brand">  
                <span className="text-warning brand-name">
                     EMS
                </span>
            </a>
            <button type="button" className="navbar-toggler bg-light" data-toggle="collapse" data-target="#nav">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse justify-content-between mx-auto" id="nav">
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <a className="nav-link text-light text-uppercase font-weight-bold px-3" href="/home ">Home</a>
                    </li>
                </ul>
          </div>
          </nav>
        )
    }
}

export default Navbar
