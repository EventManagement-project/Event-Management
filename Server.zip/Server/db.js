const mysql = require("mysql")

const connection = mysql.createConnection({
  user: "root",
  password: "manager",
  host: "localhost",
  port: 3306,
  database: "eventmanagement",
})

connection.connect()
console.log("Database is connected...");
module.exports = connection