CREATE DATABASE eventmanagement;
USE eventmanagement;

DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS orders;

CREATE TABLE admin(
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(20),
    mobile VARCHAR(15)
);

CREATE TABLE users(
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(20),
    mobile VARCHAR(15)
);

CREATE TABLE events(
    id INT PRIMARY KEY AUTO_INCREMENT,
    image VARCHAR(200),
    name VARCHAR(30),
    description VARCHAR(1000),
    eventdate DATE,
    location VARCHAR(20),
    price DECIMAL(10,2)
    
);

CREATE TABLE orders(
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_name varchar(50),
    order_placed_date DATE,
    email varchar(20),
    order_event_name varchar(30),
    amount DECIMAL(10,2),
    user_id INT,
    event_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE ON UPDATE CASCADE  
);

INSERT INTO users(first_name,last_name,email,password,mobile) VALUES("test",'testing','test@gmail',"test",19499);