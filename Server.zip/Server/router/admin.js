const express = require("express")
const db = require("../db")
const utils = require("../utils")

const router = express.Router()

//Register User in database
router.post("/register", (request, response) => {
  const { first_name, last_name, email, password, mobile } = request.body
  db.query(
    `INSERT INTO users(first_name, last_name, email, password, mobile) VALUES(?,?,?,?,?)`,
    [ first_name, last_name, email, password, mobile],
    (error, result) => {
      response.send(utils.createResult(error, result))
    }
  )
})

//Login by using email and password
router.post("/login", (request, response) => {
  const { email, password } = request.body
  const statement = `SELECT * FROM users WHERE email=? and password=?`
  db.query(statement, [email, password], (error, result) => {
    response.send(utils.createResult(error, result))
  })
})

//Chnagepassword by using id
router.put('/changepassword/:userId', (request, response) => {
  const { userId } = request.params
  const { password } = request.body
  db.query(
    `update users set password = ? where id = ?`,
    [password, userId],
    (error, result) => {
      response.send(utils.createResult(error, result))
    }
  )
})

//Update profile 
router.put('/update/:userId', (request, response) => {
  const { userId } = request.params;
  const { first_name, last_name, email, mobile } = request.body;
  db.query(
    `UPDATE users SET first_name = ?, last_name = ?, email = ?, mobile = ? WHERE id = ?`,
    [first_name, last_name, email, mobile, userId],
    (error, result) => {
      response.send(utils.createResult(error, result));
    }
  );
});

//view Profile
router.get('/profile/:userId', (request, response) => {
  const { userId } = request.params;
  db.query(
    `SELECT first_name, last_name, email, mobile FROM users WHERE id = ?`,
    [userId],
    (error, result) => {
      if (error) {
        response.send(utils.createResult(error));
      } else {
        if (result.length === 0) {
          response.status(404).json({ message: "User not found" });
        } else {
          response.json(result[0]);
        }
      }
    }
  );
});

module.exports = router
