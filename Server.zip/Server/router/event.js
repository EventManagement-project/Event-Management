const express = require("express")
const db = require("../db")
const router = express.Router()
const utils = require("../utils")

const multer = require('multer')
const upload = multer({ dest: 'uploads' })

// Display all events
router.get("/", (request, response) => {
  const query = `SELECT * FROM events`
  db.query(query, (error, result) => {
    response.send(utils.createResult(error, result))
  })
})

//Insert Event Query
router.post('/',upload.single('image'), (request, response) => {
  const {image, name, description, eventdate, location, price} = request.body;
  const filename = request.file.filename
  // const query = 'INSERT INTO events (image, name, description, eventdate, location, price) VALUES (?, ?, ?, ?, ?, ?)';
  // const value = [image, name, description, eventdate, location, price];

  db.query(`INSERT INTO events (image, name, description, eventdate, location, price) VALUES (?,?,?,?,?,?)`, [filename, name, description, eventdate, location, price], (error, result) => {
   response.send(utils.createResult(error, result))
    })
  });

  // Delete Event Query
  router.delete('/:id', (request, response) => {
    const { id } = request.params;
    const query = `DELETE FROM events WHERE id=?`;
  
    db.query(query, [id], (error, result) => {
      response.send(utils.createResult(error, result));
    });
  }); 

//update event query
router.post('/:id',upload.single('image'), (request, response) => {
  const { id } = request.params;
  const {image, name, description, eventdate, location, price } = request.body;
  const filename = request.file.filename

  const query = `UPDATE events SET image=?, name=?, description=?, eventdate=?, location=?, price=? WHERE id=?`;
  const values = [filename, name, description, eventdate, location, price, id];

  db.query(query, values, (error, result) => {
  response.send(utils.createResult(error, result))
    
  });
});

module.exports = router
