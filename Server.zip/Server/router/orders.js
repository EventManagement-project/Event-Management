const express = require("express")
const db = require("../db")
const utils = require("../utils")
const router = express.Router()
const { check, validationResult } = require('express-validator');

//show all orders to admin
router.get("/all", (request, response) => {
    console.log("All Orders Request Received... ");
    db.query("SELECT * FROM orders", (error, result) => {
      response.send(utils.createResult(error, result));
    });
  });

//get order by specific user
router.get("/:id", (request, response) => {
  const id = request.params.id;
  const statement = `SELECT e.* FROM events e INNER JOIN orders o ON e.id = o.event_id WHERE o.user_id = ?`;

  db.query(statement, [id], (error, result) => {
    if (error) {
      response.send(utils.createResult(error, null));
    } else {
      response.send(utils.createResult(null, result));
    }
  });
});


  //place order by user
  router.post("/placeorder", (request, response) => {
    const { user_id, event_id, amount, order_event_name } = request.body; 
    const order_placed_date = new Date(); 
   
    const getUserQuery = `SELECT CONCAT(first_name, ' ', last_name) AS user_name, email FROM users WHERE id = ?`;
  
    db.query(getUserQuery, [user_id], (error, userResult) => {
      if (error) {
        response.send(utils.createResult(error, null));
      } else {
        if (userResult.length === 0) {
          response.send(utils.createResult("User not found.", null));
        } else {
          const { user_name, email } = userResult[0]; 
          const insertOrderQuery = `INSERT INTO orders(order_name, order_placed_date, order_event_name,amount, user_id, event_id, email) VALUES (?, ?, ?, ?, ?, ?, ?)`;
  
          db.query(
            insertOrderQuery,
            [user_name, order_placed_date, order_event_name, amount, user_id, event_id, email],
            (error, orderResult) => {
              response.send(utils.createResult(error, orderResult));
            }
          );
        }
      }
    });
  });
  
module.exports = router