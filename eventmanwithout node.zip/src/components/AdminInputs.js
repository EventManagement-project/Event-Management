// Importing the necessary module
 import React from "react";

 // Defining the AdminInputs component
 const AdminInputs = (props) => {

  // Extracting specific properties from the props object using object destructuring  
   const { label, onChange, id, ...inputprops } = props;

  // The component returns JSX, which defines the visual part of the component
   return (

     <div className="AdminInput">

         {/* Display the label with a font size of 1.5vw */}
       <label style={{ fontSize: "1.5vw" }}>{label}</label>
        
         {/* Input field with properties spread using inputprops */}
       <input {...inputprops} onChange={onChange} />

     </div>
   );
  };

   export default AdminInputs;
