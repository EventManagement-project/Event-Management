import React from "react";

// Footer Component
const Footer = () => {
  // Get the current year
  const year = new Date().getFullYear();

  // The component returns JSX, which represents the visual part of the component
  return (
    <footer id="footer" style={{ backgroundColor: "grey", width: "100%" }}>
      
      {/* Contact Information */}
      <p class="contact-info">
        Event Management {/* Placeholder for the year */}
        
        <span class="year">{year}</span>
        <span class="phone">
          {/* Phone number link */}
          <a href="/">+912084422881</a>
        </span>
        
        <span class="email">
          {/* Email link */}
          <a href="mailto:fasir20379@gmail.com">adwait@gmail.com</a>
        </span>
      </p>
    </footer>
  );
};

// Export the Footer component
export default Footer;




// import React from "react";

// const Footer = () => {
//   const year = new Date().getFullYear();

//   return (
//     <footer id="footer" style={{ backgroundColor: "grey", width: "100%" }}>
//       <p class="contact-info">
//         Event Management <span class="year"></span>
//         <span class="phone">
//           <a href="/">+912084422881</a>
//         </span>
//         <span class="email">
//           <a href="mailto:fasir20379@gmail.com">adwait@gmail.com</a>
//         </span>
//       </p>
//     </footer>
//   );
// };

// export default Footer;
