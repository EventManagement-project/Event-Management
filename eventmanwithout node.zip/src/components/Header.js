import React from "react";
import Navbar from "./Navbar.js";
import logo from "./concert.jpeg";
import logo2 from "./wedding.jpeg";

function Header() {
  return (
    <div id="main">
      <Navbar />
      <div className="name">
        <table style={{ marginTop: "5%" }}>
          <tr>
            <td>
              <p
                className="details1"
                style={{
                  fontSize: "1.76vw",float: "left",
                  paddingLeft: "5%",paddingRight: "5%",
                  textAlign: "justify",}}>
                An event manager oversees the design, setup, and execution of events that bring people together.
                These events can range from small networking meetings with a few dozen guests to large-scale conferences with thousands of attendees over several days—and encompass everything in between.
              </p>
            </td>
            <td>
              <img
                src={logo}
                style={{
                  height: "40vh",width: "28vw",
                  float: "right",marginRight: "5%",
                }}
                alt="flight image 1"
              />
            </td>
          </tr>
          <tr style={{ paddingTop: "100%" }}>
            <td>
              <img
                src={logo2}
                style={{ height: "40vh", width: "28vw", marginLeft: "5%" }}
                alt="flight image 2"
              />
            </td>
            <td>
              <p
                className="details2"
                style={{
                  fontSize: "1.75vw",marginLeft: "5%",
                  marginRight: "5%",textAlign: "justify",
                }}>
                An event manager oversees the design, set-up, and execution of events that bring people together.
                These events can range from small networking meetings with a few dozen guests to large-scale conferences with thousands of attendees over several days—and encompass everything in between.</p>
            </td>
          </tr>
        </table>
      </div>
    </div>
  );}
export default Header;
