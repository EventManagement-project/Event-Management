import React from "react";
import logo from "./EVS.png";

function Navbar() 
{
  return (
    <nav className="nav-class">
      <label className="menu-icon" htmlFor="menu-btn">
        <span className="nav-icon"></span>
        <ul className="menu">

          <li><a href="#form3">Admin Login</a></li>
          <li><a href="/">Home</a></li>          
          <li><a href="#footer">About</a></li>
          <li><a href="#form2">Register</a></li>
          <li><a href="#footer">Contact us</a></li>
          <li><a href="#form1">Login</a></li>
        
        </ul>
      </label>
      <img
        src={logo}
        style={{ marginTop: "5%",marginLeft:"5%", height: "12%", width: "12%", float: "left" }}
        alt="airline flight"
      />
      <h1
        style={{
          textAlign: "center",color: "red",
          marginRight: "25%",marginLeft: "8%",
          fontSize: "2.5vw",marginTop: "10vh",
          marginBottom: "8vh",
          }}>Event Management Booking Services</h1>
      <br /><br /><br /><br /><br />
      <span
        style={{color:"blue",textAlign: "center",
          marginLeft: "10%",fontSize: "2vw",
          }}>Book your EVENT TODAY!</span>
    </nav>
  );}

export default Navbar;