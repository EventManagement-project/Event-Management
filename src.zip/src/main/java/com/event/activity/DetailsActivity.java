package com.event.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.event.R;
import com.event.entity.Event;
import com.event.entity.Order;
import com.event.entity.User;
import com.event.utils.API;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailsActivity extends AppCompatActivity {
    TextView textName, textDescription, textEventDate, textLocation, textPrice;
    ImageView imageView;
    Event event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        textName = findViewById(R.id.textName);
        textDescription = findViewById(R.id.textDescription);
        textEventDate = findViewById(R.id.textEventDate);
        textLocation = findViewById(R.id.textLocation);
        textPrice = findViewById(R.id.textPrice);
        imageView = findViewById(R.id.imageView);
        event = (Event) getIntent().getSerializableExtra("event");

        getEventDetails();
    }

    private void getEventDetails() {
        textName.setText("Name  :" + event.getName());
        textDescription.setText("Desriptions:  :" + event.getDescription());
        textEventDate.setText("Event Date:  :" + event.getEventdate());
        textLocation.setText("Location:(Any Location):  :" + event.getLocation());
        textPrice.setText("Event Price  :" + event.getPrice());
        Glide.with(this).load(API.BASE_URL + "/" + event.getImage()).into(imageView);
    }

    public void Payment(View view) {

        int uid = getSharedPreferences("event",MODE_PRIVATE).getInt("uid",0);
        int mid = event.getId();
        String name = event.getName();
        float amount = Float.parseFloat(event.getPrice());

        Order order = new Order();
        order.setAmount(amount);
        order.setUser_id(uid);
        order.setEvent_id(mid);
        order.setOrder_event_name(name);


        RetrofitClient.getInstance().getApi().placeOrder(order).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(response.body().getAsJsonObject().get("status").getAsString().equals("success")){
                    Toast.makeText(DetailsActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(DetailsActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

}