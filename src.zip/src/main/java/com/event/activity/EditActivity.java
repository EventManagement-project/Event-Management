package com.event.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.event.R;
import com.event.entity.User;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditActivity extends AppCompatActivity {

    EditText editFName, editLName, editPhone,editPassword,editConfirmPassword;
    Button btnSave,btnBack;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editFName= findViewById(R.id.editFName);
        editLName= findViewById(R.id.editLName);
        editPhone= findViewById(R.id.editPhone);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);

        btnSave= findViewById(R.id.btnSave);
        btnBack= findViewById(R.id.btnBack);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String firstName = extras.getString("first_name");
            String lastName = extras.getString("last_name");
            String phone = extras.getString("mobile");

            editFName.setText(firstName);
            editLName.setText(lastName);
            editPhone.setText(phone);
        }


        btnSave.setOnClickListener(new View.OnClickListener() {
            int id = getSharedPreferences("event", MODE_PRIVATE).getInt("uid", 0);
            @Override
            public void onClick(View v) {
                User user = validateUser();
                if(user!=null){
                    RetrofitClient.getInstance().getApi().updateUser(id,user).enqueue(new Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                            if(response.body().getAsJsonObject().get("status").getAsString().equals("success"))
                            {
                                Toast.makeText(EditActivity.this, "User Updated Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }
                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {
                            Toast.makeText(EditActivity.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    private User validateUser() {
        String password = editPassword.getText().toString();
        String confirmPassword = editConfirmPassword.getText().toString();
        if(password.equals(confirmPassword))
        {
            User user = new User();
            user.setFirst_name(editFName.getText().toString());
            user.setLast_name(editLName.getText().toString());
            user.setPassword(password);
            user.setMobile(editPhone.getText().toString());
            return user;
        }
        else {
            Toast.makeText(this, "passwords do not match", Toast.LENGTH_SHORT).show();
            return null;
        }
    }



}