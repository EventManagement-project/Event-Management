package com.event.activity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.event.R;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity {

    TextView textFirstName, textLastName, textEmail, textMobile;
    Button btnBack, btnEdit;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        textFirstName = findViewById(R.id.textFirstName);
        textLastName = findViewById(R.id.textLastName);
        textEmail = findViewById(R.id.textEmail);
        textMobile = findViewById(R.id.textMobile);

        btnBack = findViewById(R.id.btnBack);
        btnEdit = findViewById(R.id.btnEdit);
        toolbar= findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editIntent = new Intent(ProfileActivity.this, EditActivity.class);

                editIntent.putExtra("first_name", textFirstName.getText().toString());
                editIntent.putExtra("last_name", textLastName.getText().toString());
                editIntent.putExtra("email", textEmail.getText().toString());
                editIntent.putExtra("mobile", textMobile.getText().toString());

                startActivity(editIntent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        getUserData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.log_out, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            getSharedPreferences("event", MODE_PRIVATE).edit().putBoolean("login_status", false).apply();
            finishAffinity();
        return super.onOptionsItemSelected(item);
    }

    public void getUserData(){
        int id = getSharedPreferences("event", MODE_PRIVATE).getInt("uid", 0);
        RetrofitClient.getInstance().getApi().getUserById(id).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonArray array = response.body().getAsJsonObject().get("data").getAsJsonArray();
                for(JsonElement e: array){
                    textFirstName.setText(e.getAsJsonObject().get("first_name").getAsString());
                    textLastName.setText(e.getAsJsonObject().get("last_name").getAsString());
                    textEmail.setText(e.getAsJsonObject().get("email").getAsString());
                    textMobile.setText(e.getAsJsonObject().get("mobile").getAsString());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }


}