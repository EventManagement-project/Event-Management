package com.event.entity;

import java.io.Serializable;
import java.util.Date;

public class Order implements Serializable {
    private int id;
    private String order_name;
    private Date order_placed_date;
    private String email;
    private float amount;
    private int user_id;
    private int event_id;
    private String order_event_name;

    public Order() {
    }

    public Order(int id, String order_name, Date order_placed_date, String email, float amount, int user_id, int event_id, String order_event_name) {
        this.id = id;
        this.order_name = order_name;
        this.order_placed_date = order_placed_date;
        this.email = email;
        this.amount = amount;
        this.user_id = user_id;
        this.event_id = event_id;
        this.order_event_name = order_event_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrder_name() {
        return order_name;
    }

    public void setOrder_name(String order_name) {
        this.order_name = order_name;
    }

    public Date getOrder_placed_date() {
        return order_placed_date;
    }

    public void setOrder_placed_date(Date order_placed_date) {
        this.order_placed_date = order_placed_date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getEvent_id() {
        return event_id;
    }

    public void setEvent_id(int event_id) {
        this.event_id = event_id;
    }

    public String getOrder_event_name() {
        return order_event_name;
    }

    public void setOrder_event_name(String order_event_name) {
        this.order_event_name = order_event_name;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", order_name='" + order_name + '\'' +
                ", order_placed_date=" + order_placed_date +
                ", email='" + email + '\'' +
                ", amount=" + amount +
                ", user_id=" + user_id +
                ", event_id=" + event_id +
                ", order_event_name='" + order_event_name + '\'' +
                '}';
    }
}
