package com.event.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.event.R;
import com.event.adapter.EventListAdapter;
import com.event.entity.Event;
import com.event.utils.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AllEventFragment extends Fragment {

    RecyclerView recyclerView;
    List<Event> eventsList;
    EventListAdapter eventListAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_all_event, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerView);
        eventsList = new ArrayList<>();
        eventListAdapter = new EventListAdapter(getContext(), eventsList);

        recyclerView.setAdapter(eventListAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
        getAllEvents();
    }

    private void getAllEvents() {
        RetrofitClient.getInstance().getApi().getAllEvents().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                    JsonArray array = response.body().getAsJsonObject().get("data").getAsJsonArray();
                    for (JsonElement e : array) {
                        Event event = new Event();
                        event.setId(e.getAsJsonObject().get("id").getAsInt());
                        event.setImage(e.getAsJsonObject().get("image").getAsString());
                        event.setName(e.getAsJsonObject().get("name").getAsString());
                        event.setDescription(e.getAsJsonObject().get("description").getAsString());
                        event.setLocation(e.getAsJsonObject().get("location").getAsString());
                        event.setEventdate(e.getAsJsonObject().get("eventdate").getAsString());
                        event.setPrice(e.getAsJsonObject().get("price").getAsString());
                        eventsList.add(event);

                    }
                    eventListAdapter.notifyDataSetChanged();

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }
}