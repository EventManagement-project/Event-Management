package com.event.utils;

import com.event.entity.Order;
import com.event.entity.User;
import com.google.gson.JsonObject;



import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface API {
    String BASE_URL = "http://192.168.43.130:4000";//192.168.43.130   192.168.43.130

    @POST("/user/register")
    Call<JsonObject> registerUser(@Body User user);

    @POST("/user/login")
    Call<JsonObject> loginUser(@Body User user);

    @PUT("/user/changepassword")
    Call<JsonObject> changepassword(@Body User user);


    @PUT("/user/update/{id}")
    Call<JsonObject> updateUser(@Path("id") int id, @Body User user);

    @GET("/event/")
    Call<JsonObject> getAllEvents();

    @GET("/user/{id}")
    Call<JsonObject> getUserById(@Path("id")int id);

    @POST("/orders/placeorder")
    Call<JsonObject> placeOrder(@Body Order order);

    @GET("/orders/{id}")
    Call<JsonObject> getuserOrders(@Path("id") int id);

}
